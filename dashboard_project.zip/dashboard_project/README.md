# 📡 Telco Customer Churn — Data Visualization Dashboard

**Course:** Exploratory Data Analysis  
**Instructor:** Ali Hassan Sherazi  
**Submission Date:** 05-June-2026  

---

## 📌 Project Overview

This dashboard provides an interactive, multi-chart analysis of the **Telco Customer Churn** dataset. It covers customer demographics, service usage, contract types, and key churn drivers through 10 required chart types and fully linked sidebar filters.

---

## 🗂 Project Structure

```
dashboard_project/
├── data/
│   └── WA_Fn-UseC_-Telco-Customer-Churn.csv   ← dataset (exact name preserved)
├── notebooks/
│   └── analysis.ipynb                           ← EDA notebook
├── app.py          ← Main Streamlit application
├── charts.py       ← All chart/visualization functions
├── filters.py      ← Data loading, cleaning, filtering, KPIs
├── requirements.txt
└── README.md
```

---

## ⚙️ Installation & Running

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

### 2. Run the dashboard

```bash
streamlit run app.py
```

The dashboard will open at `http://localhost:8501` in your browser.

> **Note:** Keep the dataset file name **exactly** as `WA_Fn-UseC_-Telco-Customer-Churn.csv` inside the `data/` folder. Do NOT rename it.

---

## 📊 Charts Included

| # | Chart Type    | Insight Shown |
|---|---------------|---------------|
| 1 | Pie Chart     | Overall churn vs retention split |
| 2 | Histogram     | Distribution of monthly charges |
| 3 | Line Chart    | Avg monthly charges across tenure |
| 4 | Bar Chart     | Churn count by contract type |
| 5 | Scatter Plot  | Tenure vs total charges, coloured by churn |
| 6 | Box Plot      | Monthly charge spread by churn status |
| 7 | Heatmap       | Correlation matrix of numerical features |
| 8 | Area Chart    | Cumulative churn across tenure groups |
| 9 | Count Plot    | Internet service type frequency by churn |
| 10 | Violin Plot  | Tenure distribution by churn status |
| ★ | Pair Plot     | Bonus — pairwise numerical relationships |

---

## 🔍 Filters Available

- **Search / Text Filter** — keyword search across all columns  
- **Gender** — multi-select  
- **Contract Type** — multi-select  
- **Internet Service** — multi-select  
- **Senior Citizen** — multi-select  
- **Tenure Range** — numerical slider  
- **Monthly Charges** — numerical range slider  
- **Reset All Filters** — clears all filters instantly  

All filters are **linked to every chart**; changing any filter updates all charts simultaneously.

---

## 💡 Key Insights

1. **Month-to-month customers churn the most** — approximately 42% churn rate vs <10% for 2-year contracts.
2. **Churned customers have higher monthly charges** (median ~$79 vs ~$61 for retained).
3. **Fiber optic internet** has the highest churn proportion among internet service types.
4. **Short-tenure customers (0–12 months)** are the most at-risk group.
5. **Senior citizens** represent a small share but show elevated churn compared to non-seniors.

---

## 🛠 Technical Stack

| Tool | Role |
|------|------|
| Python 3.x | Core language |
| Pandas | Data loading, cleaning, filtering |
| NumPy | Numerical operations |
| Matplotlib | Core chart rendering |
| Seaborn | Statistical visualizations |
| Streamlit | Interactive dashboard frontend |
